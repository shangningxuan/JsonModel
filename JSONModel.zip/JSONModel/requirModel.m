//
//  requirModel.m
//  BlueCity
//
//  Created by LQ on 15/8/10.
//  Copyright (c) 2015年 王新. All rights reserved.
//

#import "requirModel.h"

@implementation requirModel
-(void)setValue:(id)value forUndefinedKey:(NSString *)key
{
    
}
@end
